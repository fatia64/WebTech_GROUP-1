<?php
// Database connection
$host = 'localhost';
$dbname = 'student';
$username = 'root';
$password = '';
$port = 3307;

$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['email'])) {
    $email = $_GET['email'];

    // Delete the record
    $sql = "DELETE FROM contact WHERE email = '$email'";

    if ($conn->query($sql)) {
        header("Location: list.php"); // Redirect to the list page
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

$conn->close();
?>