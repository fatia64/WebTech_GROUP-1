<?php


$host = 'localhost';
$dbName = 'student';
$dbUser = 'root';
$dbPassword = "";
$port = 3307;

$conn = new mysqli($host, $dbUser, $dbPassword,  $dbName, $port);

if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

 $firstName = $_POST['firstName'];
 $lastName = $_POST['lastName'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $comment = $_POST['comment'];


 $sql = "INSERT INTO contact (firstName, lastName, email, phone, comment) VALUES 
 ('$firstName', '$lastName', '$email', '$phone', '$comment')";

 if($conn->query($sql)===True){
    header("Location: list.php");
 }


}






?>