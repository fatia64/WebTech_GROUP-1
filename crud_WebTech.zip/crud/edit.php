<?php
// Database connection
$host = 'localhost';
$dbname = 'student';
$username = 'root';
$password = '';
$port = 3307;

$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the record to edit
$email = $_GET['email'];
$sql = "SELECT * FROM contact WHERE email = '$email'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

//var_dump($row);exit;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Inquiry</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        form {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="tel"], textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>  
</head>
<body>
    <h1>Edit Contact</h1>
    <form action="update.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['email']; ?>">
        <label for="firstName">First Name:</label>
        <input  type="text" id="firstName" name="firstName" value="<?php echo $row['firstName']; ?>" required><br><br>
        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" name="lastName" value="<?php echo $row['lastName']; ?>" required><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>" required><br><br>
         <label for="comment">Comment:</label>
        <textarea id="comment" name="comment" required><?php echo $row['Comment']; ?></textarea><br><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>

<?php
$conn->close();
?>