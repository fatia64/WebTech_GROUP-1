<?php
// Database connection
$host = 'localhost';
$dbname = 'student';
$username = 'root';
$password = '';
$port = 3307;


$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $comment = $_POST['comment'];

    // Update the record
    $sql = "UPDATE contact SET firstName = '$firstName', lastName = '$lastName', email = '$email', comment = '$comment' WHERE email = '$email'";

    if ($conn->query($sql)) {
        header("Location: list.php"); // Redirect to the list page
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>
